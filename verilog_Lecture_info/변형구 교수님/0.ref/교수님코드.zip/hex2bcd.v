module hex2bcd
    (
    input rst,
    input clk,      // 125MHz(8ns)
    input start,   //  100Hz(10ms)
    input [6:0] hex_in,
    output reg [7:0] bcd_out
    );
    
reg st0,st1;
wire [6:0] thex;
reg [3:0] bcdh,bcdl;
    
always@(negedge rst, posedge clk)
begin
    if (rst == 0) 
        bcd_out <= 0;
    else if (st0 & ~st1)
        bcd_out <= {bcdh,bcdl};
end        

assign thex = hex_in;
    
always@(*)
begin    
    if      (thex >= 90)  bcdh <= 9;    
    else if (thex >= 80)  bcdh <= 8;    
    else if (thex >= 70)  bcdh <= 7;    
    else if (thex >= 60)  bcdh <= 6;    
    else if (thex >= 50)  bcdh <= 5;    
    else if (thex >= 40)  bcdh <= 4;    
    else if (thex >= 30)  bcdh <= 3;    
    else if (thex >= 20)  bcdh <= 2;    
    else if (thex >= 10)  bcdh <= 1;    
    else                  bcdh <= 0;    
      
    bcdl <= thex - (bcdh * 10);
end

always@(negedge rst, posedge clk)
begin
    if (rst == 0) 
        begin
            st1  <= 0;      st0 <= 0;   
        end
    else
        begin
            st1  <= st0;      st0 <= start;
        end
end

endmodule
