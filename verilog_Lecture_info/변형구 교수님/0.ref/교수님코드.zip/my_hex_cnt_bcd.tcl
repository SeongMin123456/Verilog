restart
add_force rst {1 0ns} {0 1ps} {1 40ns}
add_force clk {0 0ns} {1 4ns} -repeat_every 8ns
add_force pls_in {0 0ns} {1 100ns} -repeat_every 200ns
add_force clr 0
add_force disp_md 0
run 3ms
add_force disp_md 1
run 3ms
add_force disp_md 0
run 3ms
add_force clr 1
run 100us
add_force clr 0
run 3ms

#run 20ms
#run 20ms
#run 20ms
#run 10ms
