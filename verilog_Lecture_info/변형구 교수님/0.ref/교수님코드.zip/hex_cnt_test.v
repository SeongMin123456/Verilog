module hex_cnt_test(
    input rst,
    input clk,      // 125MHz(8ns)
    input pls_in,   //  100Hz(10ms)
    output  reg [5:0] hex_min, hex_sec, 
    output  reg [6:0] hex_usec
    );

reg pl0,pl1;
    
always@(negedge rst, posedge clk)
begin
    if (rst == 0) 
        begin
            hex_min <= 0;   hex_sec <= 0;  hex_usec <= 0; 
        end
    else if (pl1 & ~pl0)
        begin
            if (hex_usec < 99)
                hex_usec <= hex_usec + 1;
            else
                begin
                    hex_usec <= 0;
                    if (hex_sec < 59)
                        hex_sec <= hex_sec + 1;
                    else
                        begin
                            hex_sec <= 0;
                            if (hex_min < 59)
                                hex_min <= hex_min + 1;
                            else
                                hex_min <= 0;
                        end
                end 
        end        
end

always@(negedge rst, posedge clk)
begin
    if (rst == 0) 
        begin
            pl1  <= 0;      pl0 <= 0;
        end
    else
        begin
            pl1  <= pl0;      pl0 <= pls_in;
        end
end

    
endmodule
