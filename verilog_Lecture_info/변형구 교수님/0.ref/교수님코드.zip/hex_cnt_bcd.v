module hex_cnt_bcd(
    input rst,
    input clk,      // 125MHz(8ns)
    input pls_in,   //  100Hz(10ms)
    input clr,      // BTN1 : High Active Clear
    input disp_md,   // BTN0 : High (Min,Sec) / Low (Sec,Usec)
    output  [7:0] bcd_h, bcd_l
    );

wire irst;
wire [6:0] hex_h,hex_l;
wire [5:0] hex_min,hex_sec;
wire [6:0] hex_usec;

hex2bcd u_hex2bcd_h
(
.rst        (rst        ),
.clk        (clk        ),
.start      (pls_in     ),
.hex_in     (hex_h      ),
.bcd_out    (bcd_h      )
);
 
hex2bcd u_hex2bcd_l
(
.rst        (rst        ),
.clk        (clk        ),
.start      (pls_in     ),
.hex_in     (hex_l      ),
.bcd_out    (bcd_l      )
);

assign hex_h = (disp_md == 1) ? hex_min : hex_sec;
assign hex_l = (disp_md == 1) ? hex_sec : hex_usec;

assign irst = rst & ~clr;

hex_cnt_test u_hex_cnt_test
(
.rst        (irst       ),
.clk        (clk        ),
.pls_in     (pls_in     ),
.hex_min    (hex_min    ),
.hex_sec    (hex_sec    ),
.hex_usec   (hex_usec   )
);
 
endmodule
