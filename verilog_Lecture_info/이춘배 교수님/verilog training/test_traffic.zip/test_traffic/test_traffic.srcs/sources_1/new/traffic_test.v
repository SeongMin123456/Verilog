`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2024/11/06 19:23:36
// Design Name: 
// Module Name: traffic_test
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module traffic_test(
    input crossing,
    input CLK,
    input RST,
    output reg WALK,
    output reg WAITING,
    output reg RED,
    output reg YELLOW,
    output reg GREEN
    );

parameter CLK_FREQ = 125_000_000;   // 1 sec
parameter TRANSITION = 12_500_000;   // 0.1 s

reg [1:0] curr_state, next_state;
reg [26:0] sec_count;               // 1 sec counter
reg [3:0] red_count, green_count;   // 8 sec counter
reg count_done;                     // state change
reg [26:0] ssec_count;              // 0.1 sec counter
reg [4:0] cross_count;              // 12 or 20

// debouncing
reg cross_ff1, cross_ff2;
wire cross_pressed;

// Button debouncing
always @(posedge CLK) begin
    cross_ff1 <= crossing;
    cross_ff2 <= cross_ff1;
end

// riging edge detect
assign cross_pressed = cross_ff1 & ~cross_ff2;

localparam [1:0] YELLOW_LED = 2'b00,
                 RED_LED = 2'b01,
                 CROSS = 2'b10,
                 GREEN_LED = 2'b11;

always @(posedge CLK) begin
    if(RST)     curr_state <= YELLOW_LED;
    else        curr_state <= next_state;
end // FSM

//  main logic
always @(posedge CLK) begin
    case(curr_state)
        YELLOW_LED : begin
            if(sec_count == (CLK_FREQ-1)) begin
                sec_count <= 0;
                count_done <= 1'b1;
            end else begin
                sec_count <= sec_count + 1;
                green_count <= 1'b0;
                YELLOW <= 1'b1;
                RED <= 1'b0;
                GREEN <= 1'b0;
                count_done <= 1'b0;
                WAITING <= 1'b1;
                WALK <= 1'b0;
            end
        end
        RED_LED : begin
            if(sec_count == (CLK_FREQ-1)) begin
                sec_count <= 0;
                red_count <= red_count + 1;
                if(red_count == 4'd8) begin
                    red_count <= 0;
                    count_done <= 1'b1;
                end
            end else begin
                sec_count <= sec_count + 1;
                YELLOW <= 1'b0;
                RED <= 1'b1;
                GREEN <= 1'b0;
                count_done <= 1'b0;
                WAITING <= 1'b1;
                WALK <= 1'b0;
            end
        end
        CROSS : begin
            if(red_count <= 2) begin
                if(ssec_count == (TRANSITION -1)) begin
                    ssec_count <= 0;
                    cross_count <= cross_count + 1;
                    if(cross_count == 20) begin
                        count_done <= 1'b1;
                        cross_count <= 0;
                        red_count <= 0;
                    end
                end else begin
                    ssec_count <= ssec_count + 1;
                    count_done <= 1'b0;
                end
            end else if(red_count > 2) begin
                if(ssec_count == (TRANSITION -1)) begin
                    ssec_count <= 0;
                    cross_count <= cross_count + 1;
                    if(cross_count == 12) begin
                        count_done <= 1'b1;
                        cross_count <= 0;
                        red_count <= 0;
                    end
                end else begin
                    ssec_count <= ssec_count + 1;
                    count_done <= 1'b0;
                end
            end
            else begin
                ssec_count <= 0;
                cross_count <= 0;
            end
        end
        GREEN_LED : begin
            if(sec_count == (CLK_FREQ-1)) begin
                sec_count <= 0;
                green_count <= green_count + 1;
                if(green_count == 4'd8) begin
                    green_count <= 0;
                    count_done <= 1'b1;
                end
            end else begin
                sec_count <= sec_count + 1;
                red_count <= 1'b0;
                YELLOW <= 1'b0;
                RED <= 1'b0;
                GREEN <= 1'b1;
                count_done <= 1'b0;
                WAITING <= 1'b0;
                WALK <= 1'b1;
            end
        end
    endcase
end


always @(curr_state, count_done, cross_pressed) begin
    case(curr_state)
        YELLOW_LED : begin
            if(count_done)             next_state <= RED_LED;
            else                       next_state <= YELLOW_LED;
        end
        RED_LED : begin
            if(count_done)             next_state <= GREEN_LED;
            else if(cross_pressed)     next_state <= CROSS;
            else                       next_state <= RED_LED;
        end
        CROSS : begin
            if(count_done)             next_state <= GREEN_LED;
            else                       next_state <= CROSS;
        end
        GREEN_LED : begin
            if(count_done)             next_state <= YELLOW_LED;
            else                       next_state <= GREEN_LED;
        end
     endcase
end

endmodule